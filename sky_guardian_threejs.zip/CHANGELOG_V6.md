# V6 — Jason boss

- Adicionado `Jason | MultiVersus` como inimigo/boss local.
- Modelo enviado pelo usuário foi otimizado para runtime: o GLB original tinha ~44,8 MB e 129 animações; a versão do jogo mantém mesh/texturas/rig e 8 clips úteis em ~11,5 MB.
- Jason usa o mesmo ajuste de eixo do Superman (`+X` do rig -> `+Z` do jogo, rotação Y de -90°).
- IA de perseguição terrestre com idle, caminhada, combo corpo a corpo e shoulder bash.
- Barra de vida do boss: 180 HP.
- Superman agora tem 100 HP e pode receber dano/knockback.
- Soco normal causa 22 de dano quando conecta.
- Super soco causa 48 de dano, aplica knockback e interrompe ataques do boss.
- Visão de calor causa 18 de dano quando a mira cruza o volume do Jason.
- Hit reaction e animação de derrota do próprio Jason.
- `R` reinicia jogador, boss e objetivo dos anéis.
