# V4 — Decolagem, pouso, super soco e direção corrigida

- O Superman agora inicia no chão.
- `Espaço` no chão ou `F` inicia decolagem usando `C003_Flying_Intro` (fallback `C003_Jump_01`).
- `F` durante o voo inicia aproximação para pouso.
- `Ctrl`/`C` descendo próximo do chão inicia pouso automático.
- Pouso usa a animação nativa `C003_Land`.
- O sistema detecta a superfície abaixo, permitindo pousar também no topo dos prédios.
- No chão, `WASD` permite deslocamento e usa `C003_Run_01` / `C003_Idle_01`.
- `Shift + E` ou `X` executa SUPER SOCO usando `C003_N_Attack_01`, com onda de impacto, empurrão em carros/NPCs próximos e tremor de câmera.
- O personagem deixou de usar apenas rotação de 180° para corrigir o eixo frontal. Agora o GLB fica dentro de um wrapper espelhado em Z (`scale.z = -1`), alinhando modelo e root motion com o +Z usado pelo gameplay.
- HUD agora mostra NO SOLO, DECOLANDO, VOO, APROXIMAÇÃO e POUSANDO.
