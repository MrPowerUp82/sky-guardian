# V12.1 — Runtime hotfix

- Corrige `ReferenceError: loopMode is not defined` em `enemyPlayClip()`.
- `enemyPlayClip()` agora usa `THREE.LoopRepeat` como modo padrão, mantendo `LoopOnce` para one-shots.
- Migra `THREE.Clock` para `THREE.Timer` no jogo e no configurador, conforme a API do Three.js r186.
- Troca `THREE.PCFSoftShadowMap` removido por `THREE.PCFShadowMap`.
- Adiciona `favicon.svg`, removendo o 404 de `/favicon.ico`.
- Mantém todas as funcionalidades da V12 (visão de calor intro/hold, Flying Stop, air idle e voo Mach 1+).
