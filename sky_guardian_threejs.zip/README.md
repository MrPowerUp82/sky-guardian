# Sky Guardian / Superman V13

> V13 adiciona Leap Attack completo usando os clips autorais do GLB original, com mira assistida, trajetória física, impacto em área e recuperação.

# Superman Three.js — Open City V12

Protótipo de fã em Three.js com o modelo Superman | MultiVersus e um boss Jason | MultiVersus, ambos carregados localmente. A cidade continua usando os pacotes CC0 já documentados em `ASSETS.md`.

## Rodar

Na pasta do projeto:

```bash
python -m http.server 8080
```

Abra `http://localhost:8080`.

Não abra o `index.html` diretamente com `file://`, porque GLB e módulos ES precisam ser servidos por HTTP.

## Controles

- `W A S D`: mover / manobrar
- Mouse: mirar
- `F`: começar a voar / parar de voar (pouso automático)
- Durante o voo, `W` segue a mira em **3D**: mire para cima para subir e para baixo para descer
- Durante o voo, `S` recua na direção oposta à mira e `A/D` fazem strafe lateral
- `Shift + W` durante o voo: superaceleração progressiva até Mach 1+
- `E`: soco normal
- `Shift + E` ou `X`: super soco
- `C`: Leap Attack (no solo)
- segure `Q`: visão de calor contínua; solte para resfriar
- `R`: reiniciar luta/objetivos
- `Esc`: liberar o mouse

## Boss Jason

Jason nasce à frente do Superman, persegue o jogador pelas ruas e usa animações originais do GLB para idle, caminhada, combos, shoulder bash, hit reaction e derrota. Ele possui 180 HP. O Superman possui 100 HP; ao chegar a zero, a luta reinicia automaticamente.

O modelo do Jason foi reduzido de aproximadamente 44,8 MB / 129 clips para aproximadamente 11,5 MB / 8 clips de gameplay, sem remover o mesh, texturas ou skeleton necessários.

## Observação de direitos

Este projeto continua sendo um fan prototype. Os personagens Superman, Jason Voorhees, MultiVersus e seus designs pertencem aos respectivos titulares. Consulte `ATTRIBUTION.md` e a página de origem de cada modelo antes de redistribuir/publicar.

## Configurador de animações 2.0 (V8)

Com o servidor rodando, abra:

`http://localhost:8080/animation-configurator.html`

A ferramenta permite visualizar todos os clips dos GLBs, corrigir orientação/espelhamento, inspecionar bones, criar hitboxes/hurtboxes e marcar eventos de dano diretamente na timeline. Use **Aplicar no jogo neste navegador** para testar sem editar código e **Exportar JSON** para enviar a configuração a uma IA.

Veja `ANIMATION_CONFIGURATOR.md` para o fluxo completo.

## V8 — Configuração de animação dirigida por dados

A V8 adiciona `animation-config-runtime.js` e a pasta `config/`. O jogo lê automaticamente os JSONs de Superman/Jason e usa seus slots, orientação, velocidade, fade e eventos de combate. O configurador 2.0 também pode aplicar uma configuração via `localStorage` para testar sem editar `main.js`.

Abra `animation-configurator.html`, configure o personagem, use **Aplicar no jogo neste navegador** e recarregue `index.html`. Para compartilhar a configuração, use **Exportar JSON**.


## V9 — Cidade e voo guiado pela mira

A malha urbana foi ampliada para nove avenidas por nove ruas, com quarteirões planejados por distrito: núcleo comercial mais vertical, zona intermediária mista e bordas com menor densidade. O gerador também cria parques, praças, faixas de pedestre, marcações de pista, mais tráfego, mais pedestres e um skyline decorativo além do limite jogável.

O voo não usa mais teclas separadas de subir/descer. `F` inicia o voo e `F` novamente encerra o voo com pouso automático na rua ou telhado abaixo do personagem. Enquanto o voo está ativo, a mira define o vetor 3D completo: `W` acelera exatamente para onde a câmera aponta, inclusive para cima ou para baixo.



## V11 — Grounding / personagens sem afundar

A V11 substitui a antiga suposição de que todo o chão estava em `Y=0` por superfícies visuais reais. Ruas, calçadas/pads e telhados agora participam do cálculo de altura. Superman, Jason e NPCs animados também recebem um **foot lock** pós-animação: o jogo acompanha bones de calcanhar/pé/dedos e corrige apenas o visual do modelo depois do `AnimationMixer`, sem alterar a física do personagem. Isso evita que animações de idle, caminhada, soco e pouso empurrem os pés para dentro do asfalto.

A correção é liberada suavemente durante decolagem/voo e reativada quando o personagem está no chão. Os NPCs passam a usar a altura real da rua/calçada em vez de `Y=0`.

## V10 — Visão de calor e voo supersônico

- **Visão de calor:** segure `Q`. Os feixes seguem a mira, respeitam oclusão por prédios, causam dano contínuo em Jason e superaquecem se usados por tempo demais. Solte `Q` para resfriar.
- **Voo supersônico:** durante o voo, segure `W + Shift`. A aceleração aumenta progressivamente até atravessar a barreira do som. O HUD mostra o Mach e a passagem por Mach 1 gera um boom sônico. Velocidade máxima ajustada: ~420 m/s (~1512 km/h / Mach 1,22).
- Em alta velocidade, a câmera abre o FOV e recua, aparecem rastros de velocidade e as curvas ganham inércia.


## V12 — visão de calor com hold-loop + idle aéreo

- **Visão de calor em duas fases:** ao pressionar `Q`, toca primeiro o clip autoral completo (`C003_Laser_Air` no ar ou `C003_Laser_Ground` no chão). Se `Q` continuar pressionado quando o clip termina, o jogo entra em um **hold-loop** construído a partir da parte final de menor movimento do mesmo clip e reproduzido em `LoopPingPong` para esconder a emenda. Ao soltar `Q`, o loop termina e a locomoção normal reassume suavemente.
- O GLB original não possui um clip separado chamado `Laser_*_Loop`; por isso o hold-loop é derivado do próprio clip autoral em runtime, sem inventar uma pose nova.
- **Desaceleração no ar:** quando a velocidade cai e não há comando de movimento, toca `C003_Flying_Stop` uma vez.
- **Parado no ar:** depois do `Flying_Stop`, Superman entra em `C003_S08_Emote_CharacterSelect_Loop` enquanto permanecer praticamente imóvel.
- `Flying_Stop` é interruptível: voltar a mover, atacar ou iniciar a visão de calor cancela a transição para não deixar os controles presos.
- O runtime do Superman agora preserva 15 clips, incluindo `C003_Laser_Ground` e `C003_S08_Emote_CharacterSelect_Loop`.


## V13 — Leap Attack

O GLB original do Superman contém dois clips específicos para esse movimento: `C003_LeapAttack` (1,88 s) e `C003_LeapAttackLand` (1,04 s). Eles foram restaurados no GLB otimizado do jogo.

Pressione `C` no solo. Se Jason estiver dentro do cone da mira, a uma distância útil e sem prédio bloqueando a linha de visão, o golpe trava o destino nele. Caso contrário, Superman salta na direção horizontal da mira. O deslocamento usa uma trajetória parabólica em world-space para respeitar a escala da cidade, enquanto os clips autorais cuidam da pose.

O ataque não atravessa prédios: a trajetória é encurtada antes da fachada. No touchdown, o jogo troca para `C003_LeapAttackLand`, cria uma onda de impacto, aplica dano/knockback em Jason e empurra atores leves próximos. O foot-lock é suspenso durante o salto e reativado na recuperação para evitar afundamento no chão.


## V15 — Reentrada cinematográfica

Ao voar para fora da atmosfera, Superman entra no cenário orbital. Para voltar, aponte para a Terra e avance. A aproximação inicia automaticamente uma sequência de reentrada com plasma, som, shake de câmera e FOV dinâmico. A cidade reaparece durante a descida e o controle é devolvido ainda em voo.

A escala Terra/Lua/Sol no cenário orbital é artisticamente comprimida para gameplay; as proporções astronômicas reais não cabem de forma prática na mesma escala da cidade.
