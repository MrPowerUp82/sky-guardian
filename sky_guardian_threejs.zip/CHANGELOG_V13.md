# V13 — Leap Attack autoral

- Restaurados do GLB original do Superman os clips `C003_LeapAttack` e `C003_LeapAttackLand` no GLB otimizado de runtime.
- Novo comando `C`: Leap Attack no solo.
- O ataque usa uma sequência completa: wind-up autoral, salto físico no mundo, impacto e recuperação autoral.
- Mira assistida em Jason quando ele está dentro do cone frontal e há linha de visão; fora disso, o salto segue a direção horizontal da mira.
- Alcance limitado e colisão preventiva com prédios para impedir atravessar fachadas ou teleportar para telhados.
- Trajetória parabólica calculada no mundo, com altura adaptativa à distância.
- Impacto em área com 42 de dano, knockback, câmera, onda de choque e empurrão de carros/NPCs próximos.
- `C003_LeapAttackLand` começa exatamente no touchdown; o foot-lock volta durante a recuperação para manter os pés apoiados.
- O Configurador de Animações 2.0 agora expõe os slots `leapAttack` e `leapAttackLand`.
- Adicionados testes automatizados para garantir que os dois clips e os slots continuem presentes em builds futuras.
