# V8 — Animation Configurator 2.0

## Principal

- O jogo agora carrega automaticamente `config/superman-animation-config.json` e `config/jason-animation-config.json`.
- O Configurador 2.0 pode salvar uma configuração no `localStorage`; essa configuração tem prioridade no jogo no mesmo navegador/origem.
- Schema de configuração atualizado para `schemaVersion: 2`.
- Slots de gameplay agora podem conter `events` com tempo local do clip.
- Eventos de `damage`, `heatVision` e `cameraShake` são processados pelo runtime.
- Hitboxes/hurtboxes podem ser ligadas a bones reais do esqueleto.
- O dano configurado usa a posição mundial do bone/hitbox no frame do evento.

## Configurador 2.0

- visualização opcional do SkeletonHelper;
- busca/lista de bones;
- editor de hitbox sphere/box;
- offset local do volume em relação ao bone;
- finalidade attack/hurtbox/sensor;
- marcadores de eventos sobre a timeline;
- criação/remoção de eventos por slot;
- exportação JSON/Markdown;
- importação JSON;
- botão “Aplicar no jogo neste navegador”.

## Qualidade

- novo `animation-config-runtime.js` para normalização, slots, hitboxes e fila de eventos;
- `npm test` configurado;
- testes do runtime de configuração adicionados.
