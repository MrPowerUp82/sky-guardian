# V10 — Heat Vision + Supersonic Flight

- Heat Vision is now a held ability (`Q`) with continuous aiming, building/ground occlusion, impact glow, continuous damage and an overheat/cooldown meter.
- `Shift + W` while flying progressively accelerates Superman instead of instantly switching speeds.
- Flight can cross Mach 1 (343 m/s) and reach about 420 m/s / 1512 km/h.
- Sonic boom triggers exactly when crossing Mach 1, with expanding shock rings, screen impulse, camera shake and synthesized boom audio.
- Added speed streaks, dynamic camera distance and FOV up to 96 degrees at extreme speed.
- Steering becomes heavier at high speed to avoid arcade-like instant 180-degree turns.
- Added swept building collision so Superman does not tunnel through buildings at supersonic speeds.
- HUD now shows Mach number and Heat Vision temperature/status.
