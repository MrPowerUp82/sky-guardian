import test from 'node:test';
import assert from 'node:assert/strict';
import { neutralizeVerticalTracks, STAND_PELVIS_Y } from '../hero-motion.js';

const close = (a, b) => assert.ok(Math.abs(a - b) < 1e-6, `${a} !== ${b}`);

test('neutralizeVerticalTracks fixa Y da pelvis em STAND_PELVIS_Y', () => {
  const tracks = [{ name: 'fml_un_C_pelvis_att.position', values: new Float32Array([0, -0.234, 0.1, 0.2, 2.031, 0.3]) }];
  const [out] = neutralizeVerticalTracks(tracks);
  close(STAND_PELVIS_Y, 1.994);
  [0, STAND_PELVIS_Y, 0.1, 0.2, STAND_PELVIS_Y, 0.3].forEach((v, i) => close(out.values[i], v));
});

test('neutralizeVerticalTracks não altera outras tracks', () => {
  const root = { name: 'Root.position', values: new Float32Array([1, 2, 3]) };
  const quat = { name: 'fml_un_C_pelvis_att.quaternion', values: new Float32Array([0, 0, 0, 1]) };
  const [r, q] = neutralizeVerticalTracks([root, quat]);
  assert.deepEqual([...r.values], [1, 2, 3]);
  assert.deepEqual([...q.values], [0, 0, 0, 1]);
});

test('neutralizeVerticalTracks não muta a entrada', () => {
  const values = new Float32Array([0, -0.234, 0.1]);
  neutralizeVerticalTracks([{ name: 'fml_un_C_pelvis_att.position', values }]);
  close(values[1], -0.234);
});

test('neutralizeVerticalTracks aceita constantY customizado', () => {
  const [out] = neutralizeVerticalTracks([{ name: 'fml_un_C_pelvis_att.position', values: new Float32Array([0, 5, 0]) }], 1.5);
  close(out.values[1], 1.5);
});
