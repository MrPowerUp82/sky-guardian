export const STAND_PELVIS_Y = 1.994;
export const VERTICAL_TRACK_PATTERN = /^fml_un_C_pelvis_att\.position$/i;

export function neutralizeVerticalTracks(tracks, constantY = STAND_PELVIS_Y) {
  return tracks.map(track => {
    if (VERTICAL_TRACK_PATTERN.test(track.name)) {
      const values = new Float32Array(track.values);
      for (let i = 1; i < values.length; i += 3) {
        values[i] = constantY;
      }
      return { ...track, values };
    }
    return track;
  });
}
