# Sky Guardian Superman V15

## Reentrada cinematográfica

- A volta do espaço para a cidade agora é uma sequência contínua de ~6,4 s em vez de uma troca instantânea de cenário.
- Aproximação visual da Terra antes da entrada atmosférica.
- Plasma procedural ao redor do Superman, com núcleo quente, camada externa e onda de choque.
- Trilhas de partículas/linhas de plasma orientadas pela velocidade.
- Vinheta atmosférica dinâmica na tela, mais intensa no pico da reentrada.
- Som procedural WebAudio com rumble grave + ruído filtrado que reage à intensidade do plasma.
- FOV e distância de câmera específicos para a reentrada, com tremor progressivo.
- Fase de blackout/transição seguida de descida sobre a cidade.
- Cidade reaparece em grande altitude e cresce visualmente durante a descida.
- Jason, NPCs e simulação urbana ficam pausados/ocultos durante a sequência.
- Ao terminar, o controle é devolvido em voo a ~620 m de altitude, sem pouso forçado.
- Reset limpa corretamente efeitos e áudio de reentrada.
