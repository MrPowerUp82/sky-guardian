# V11 — Ground Contact / Foot Lock

- Corrigido o problema de Superman, Jason e NPCs afundarem no piso.
- O chão lógico agora acompanha a altura visível das ruas (`0.085 m`), pads/calçadas (`0.06 m`) e telhados.
- Adicionado sistema de **foot lock** baseado nos bones de heel/toe/foot dos personagens animados.
- A correção acontece **depois do AnimationMixer**, portanto compensa deslocamentos verticais introduzidos pelas animações sem mover o collider/root de gameplay.
- Superman recebe foot lock somente quando está no estado `grounded`; durante voo/decolagem a correção volta suavemente ao offset original.
- Jason recebe grounding contínuo enquanto permanece como boss terrestre.
- NPCs passam a nascer e caminhar na altura real da rua/calçada e usam foot lock quando o rig possui bones de pé identificáveis.
- Ordem do frame ajustada para: movimento -> mixers -> grounding -> eventos/hitboxes/heat vision -> câmera.
- Mantidos visão de calor contínua, voo supersônico e sistema de configuração V8/V10.
- `npm run check` e `npm test`: 15/15 testes passando.
