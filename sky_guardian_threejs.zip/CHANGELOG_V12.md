# V12 — Heat Vision Hold Loop + Air Stop/Idle

## Visão de calor

- Conferido o GLB original do Superman: existem `C003_Laser_Air` e `C003_Laser_Ground`, mas não há um clip separado `Laser_Air_Loop`/`Laser_Ground_Loop`.
- A V12 preserva também `C003_Laser_Ground` no GLB otimizado.
- Ao pressionar `Q`, toca o clip autoral de início correspondente ao estado (ar/chão).
- Se `Q` continuar pressionado ao final, o jogo gera um hold-loop a partir da cauda de menor movimento desse mesmo clip e usa `THREE.LoopPingPong` para suavizar a costura.
- Ao soltar `Q` durante o intro, o intro termina normalmente e não entra no loop.
- Ao soltar `Q` durante o hold, o loop faz fade-out e a animação de locomoção reassume.

## Parada no ar

- Adicionado `C003_S08_Emote_CharacterSelect_Loop` ao GLB runtime a partir do arquivo original.
- Sem input e abaixo de ~4,2 m/s, toca `C003_Flying_Stop` uma única vez.
- Ao terminar, entra em `C003_S08_Emote_CharacterSelect_Loop` como idle aéreo.
- `Flying_Stop` pode ser interrompido imediatamente por movimento, ataques ou visão de calor.

## Configurador

- Novo slot `airIdle` → `C003_S08_Emote_CharacterSelect_Loop`.
- Novo slot `heatVisionGround` → `C003_Laser_Ground`.

## Verificação

- Runtime Superman GLB: 15 clips.
- `npm test`: 17/17 testes.
- `npm run check`: validação de sintaxe aprovada.
