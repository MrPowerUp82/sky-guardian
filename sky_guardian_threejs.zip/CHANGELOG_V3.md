# V3 — Superman MultiVersus

- Integração do GLB enviado pelo usuário.
- Redução do runtime do personagem de ~57 MB / 181 clips para ~11 MB / 13 clips.
- Remoção do personagem Quaternius e da capa procedural da versão anterior.
- Uso da capa e rig nativos do modelo.
- Loop de hover: `C003_Flying_Hold`.
- Voo em movimento: `C003_Flying`.
- Soco: `C003_Punch_01` com fallback `C003_N_Attack_01`.
- Visão de calor: `C003_Laser_Air` + feixe duplo.
- Correção do sistema de one-shot para ataques não serem interrompidos imediatamente pelo loop de voo.
- Escala normalizada para ~2,05 m.
- Crédito e aviso de propriedade intelectual adicionados.
