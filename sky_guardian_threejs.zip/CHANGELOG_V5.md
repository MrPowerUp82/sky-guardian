# V5 — correção definitiva da direção de voo

- Corrigido Superman voando 90° de lado.
- O rig importado foi verificado: frente do personagem = eixo local **+X**.
- O sistema de movimento usa eixo local **+Z** como frente.
- Removido `scale.z = -1`, que apenas espelhava o modelo e não corrigia a diferença de eixo.
- Adicionado `modelOrientation.rotation.y = -Math.PI / 2`, convertendo +X para +Z.
- Escala volta a ser positiva, evitando problemas de culling/skinning causados por escala negativa.
- Decolagem, pouso, voo, super soco e visão de calor permanecem da V4.
