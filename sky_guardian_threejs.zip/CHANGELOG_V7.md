# V7 — Configurador de animações

- Adicionado `animation-configurator.html`, uma ferramenta visual 3D para configurar animações dos personagens.
- Seleção entre Superman e Jason usando os GLBs locais do jogo.
- Lista automática de clips e duração.
- Playback, pause, restart e scrubbing da animação.
- Ajustes de speed, fade, loop e remoção de `Root.position`.
- Ajuste visual de rotação XYZ, espelhamento XYZ e altura alvo.
- Mapeamento de clips para ações semânticas do jogo.
- Exportação/importação JSON amigável para IA.
- Exportação de resumo Markdown.
- Adicionado atalho para o configurador no menu inicial do jogo.
