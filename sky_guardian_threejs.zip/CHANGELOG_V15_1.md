# Sky Guardian Superman V15.1

- Corrigida a orientação visual do Superman durante o voo.
- O corpo agora aponta pelo vetor 3D exato da mira, inclusive em subidas e mergulhos muito inclinados.
- A rotação usa quaternion/`lookAt` em vez de combinar pitch e yaw manualmente.
- O bank de A/D continua existindo, mas agora gira ao redor do eixo de voo sem desviar a direção frontal.
- A mesma correção é usada no voo orbital.
