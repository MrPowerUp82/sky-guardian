# Sky Guardian Superman V14

## Novo recurso: voo para fora da Terra

- Adicionada transição atmosférica progressiva quando Superman sobe muito alto.
- Ao cruzar a altitude de entrada, o jogo muda para um cenário orbital com a Terra, o Sol e a Lua visíveis.
- Em órbita, Superman continua voando livremente em 3D.
- Se o jogador apontar para a Terra e voar de volta, ocorre a reentrada e o cenário retorna para a cidade.
- A cidade, anéis e HUD do boss são ocultados em órbita.
- A câmera foi ajustada para suportar distâncias orbitais e ignorar colisão de prédios no espaço.
- A iluminação, o fundo e a névoa agora fazem blend gradual entre atmosfera e espaço.
