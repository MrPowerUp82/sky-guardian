# V9 — Cidade por distritos e voo 3D guiado pela mira

## Cidade
- Grade urbana ampliada de 7x7 para 9x9 e limite jogável expandido.
- Gerador de quarteirões por distritos: core comercial, zona mista e periferia de menor densidade.
- Variações reais de lote: torres com anexos, blocos de 2/3/4 prédios, praças e parques.
- Parques com agrupamentos de árvores e praças arborizadas.
- Faixas de pedestres e marcações de pista renderizadas com InstancedMesh.
- Mais carros e pedestres circulando pela cidade.
- Skyline decorativo no perímetro para evitar o fim visual abrupto da cidade.
- Área de sombras do sol ampliada para cobrir a nova malha urbana.

## Voo
- Removidos os comandos dedicados de subir/descer (`Espaço`, `Ctrl`, `C`).
- `F` agora é o controle explícito de começar/parar voo.
- `W` em voo acelera no vetor 3D da mira, inclusive subida e descida.
- `S` recua na direção oposta da mira; `A/D` fazem strafe lateral.
- Câmera passa a olhar para frente da mira em vez de sempre olhar diretamente para o personagem.
- Corpo do Superman acompanha yaw/pitch da mira durante o voo.
- Parar o voo ativa um pouso automático na rua ou telhado imediatamente abaixo.
- Visão de calor continua alinhada ao centro da mira e agora compartilha a mesma direção usada pelo voo.
