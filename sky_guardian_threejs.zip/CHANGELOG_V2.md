# Sky Guardian — correções visuais V2

Esta revisão foi feita a partir das capturas de tela do protótipo em execução.

## Corrigido

- Herói reduzido para ~1,95 m de altura em vez de ~3,65 m.
- Capa deixou de ser um retângulo grande: agora é uma malha trapezoidal segmentada com ondulação baseada na velocidade.
- Prédios não são mais escalados pela altura arbitrária; agora usam o footprint como referência, preservando melhor portas, janelas e proporções.
- Centro urbano expandido para 7 avenidas/ruas principais e 36 quarteirões.
- Adicionadas bases de concreto/calçada sob os quarteirões para evitar grama aparecendo no centro.
- Cidade ocupa praticamente toda a área jogável, reduzindo o "campo vazio" visível ao sair do centro.
- Colisão simples do herói com prédios.
- Colisão da câmera em terceira pessoa com prédios para evitar a câmera atravessar fachadas.
- Câmera ficou um pouco mais próxima do herói e com FOV menos exagerado.
- Tráfego e pedestres percorrem a nova área maior.

Os modelos CC0 continuam sendo carregados das mesmas fontes documentadas em `ASSETS.md`.
